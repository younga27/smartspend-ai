import { decimal, int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, json } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  emailNotificationsEnabled: boolean("emailNotificationsEnabled").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Subscriptions table - stores all user subscription entries
 */
export const subscriptions = mysqlTable("subscriptions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  currency: varchar("currency", { length: 3 }).default("USD").notNull(),
  billingFrequency: mysqlEnum("billingFrequency", ["daily", "weekly", "monthly", "quarterly", "yearly"]).notNull(),
  category: varchar("category", { length: 50 }).notNull(), // e.g., "streaming", "productivity", "fitness", "software", "other"
  nextBillingDate: timestamp("nextBillingDate").notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  isFreeTrialActive: boolean("isFreeTrialActive").default(false).notNull(),
  trialEndDate: timestamp("trialEndDate"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Subscription = typeof subscriptions.$inferSelect;
export type InsertSubscription = typeof subscriptions.$inferInsert;

/**
 * Alerts table - stores smart alerts for renewals, trial expirations, price changes
 */
export const alerts = mysqlTable("alerts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  subscriptionId: int("subscriptionId").notNull(),
  alertType: mysqlEnum("alertType", ["upcoming_renewal", "trial_expiration", "price_increase", "custom"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  triggerDate: timestamp("triggerDate").notNull(),
  isRead: boolean("isRead").default(false).notNull(),
  isDismissed: boolean("isDismissed").default(false).notNull(),
  emailSent: boolean("emailSent").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = typeof alerts.$inferInsert;

/**
 * Chat messages table - stores AI chat assistant conversation history
 */
export const chatMessages = mysqlTable("chatMessages", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  role: mysqlEnum("role", ["user", "assistant"]).notNull(),
  content: text("content").notNull(),
  metadata: json("metadata"), // Optional metadata like context about subscriptions
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = typeof chatMessages.$inferInsert;

/**
 * Spending analytics table - pre-computed monthly and annual spending breakdowns
 */
export const spendingAnalytics = mysqlTable("spendingAnalytics", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  month: varchar("month", { length: 7 }).notNull(), // Format: YYYY-MM
  totalMonthlySpending: decimal("totalMonthlySpending", { precision: 12, scale: 2 }).notNull(),
  categoryBreakdown: json("categoryBreakdown").notNull(), // {category: amount, ...}
  activeSubscriptionCount: int("activeSubscriptionCount").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SpendingAnalytics = typeof spendingAnalytics.$inferSelect;
export type InsertSpendingAnalytics = typeof spendingAnalytics.$inferInsert;

/**
 * AI Savings Recommendations table - stores generated recommendations
 */
export const savingsRecommendations = mysqlTable("savingsRecommendations", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  potentialSavings: decimal("potentialSavings", { precision: 10, scale: 2 }).notNull(),
  relatedSubscriptionIds: json("relatedSubscriptionIds").notNull(), // Array of subscription IDs
  isArchived: boolean("isArchived").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SavingsRecommendation = typeof savingsRecommendations.$inferSelect;
export type InsertSavingsRecommendation = typeof savingsRecommendations.$inferInsert;