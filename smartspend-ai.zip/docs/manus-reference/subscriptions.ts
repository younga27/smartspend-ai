import { describe, it, expect, beforeAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock user context
const mockUser = {
  id: 999,
  openId: "test-user-999",
  email: "test@example.com",
  name: "Test User",
  loginMethod: "test",
  role: "user" as const,
  createdAt: new Date(),
  updatedAt: new Date(),
  lastSignedIn: new Date(),
};

function createMockContext(): TrpcContext {
  return {
    user: mockUser,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("Subscriptions Router", () => {
  let caller: ReturnType<typeof appRouter.createCaller>;

  beforeAll(() => {
    const ctx = createMockContext();
    caller = appRouter.createCaller(ctx);
  }, { timeout: 30000 });

  it("should create a subscription", async () => {
    const result = await caller.subscriptions.create({
      name: "Netflix",
      description: "Streaming service",
      amount: 15.99,
      currency: "USD",
      billingFrequency: "monthly",
      category: "entertainment",
      nextBillingDate: new Date("2026-07-09"),
    });

    expect(result).toBeDefined();
    expect(result.name).toBe("Netflix");
    expect(result.billingFrequency).toBe("monthly");
  }, { timeout: 30000 });

  it("should list subscriptions", async () => {
    const result = await caller.subscriptions.list();
    expect(Array.isArray(result)).toBe(true);
  }, { timeout: 30000 });

  it("should update a subscription", async () => {
    const created = await caller.subscriptions.create({
      name: "Hulu",
      description: "Video streaming",
      amount: 7.99,
      currency: "USD",
      billingFrequency: "monthly",
      category: "entertainment",
      nextBillingDate: new Date("2026-07-20"),
    });

    const updated = await caller.subscriptions.update({
      id: created.id,
      name: "Hulu Premium",
    });

    expect(updated.name).toBe("Hulu Premium");
  }, { timeout: 30000 });

  it("should delete a subscription", async () => {
    const created = await caller.subscriptions.create({
      name: "Disney+",
      description: "Disney streaming",
      amount: 10.99,
      currency: "USD",
      billingFrequency: "monthly",
      category: "entertainment",
      nextBillingDate: new Date("2026-07-25"),
    });

    const result = await caller.subscriptions.delete({ id: created.id });
    expect(result.success).toBe(true);
  }, { timeout: 30000 });

  it("should update subscription active status", async () => {
    const created = await caller.subscriptions.create({
      name: "Amazon Prime",
      description: "Prime membership",
      amount: 139,
      currency: "USD",
      billingFrequency: "yearly",
      category: "shopping",
      nextBillingDate: new Date("2027-06-09"),
    });

    const updated = await caller.subscriptions.update({
      id: created.id,
      isActive: false,
    });

    expect(updated.isActive).toBe(false);
  }, { timeout: 30000 });
});

describe("Recommendations Router", () => {
  let caller: ReturnType<typeof appRouter.createCaller>;

  beforeAll(() => {
    const ctx = createMockContext();
    caller = appRouter.createCaller(ctx);
  }, { timeout: 30000 });

  it("should list recommendations", async () => {
    const result = await caller.recommendations.list();
    expect(Array.isArray(result)).toBe(true);
  }, { timeout: 30000 });

  it("should generate recommendations", async () => {
    const result = await caller.recommendations.generate();
    expect(result).toBeDefined();
  }, { timeout: 30000 });
});

describe("Alerts Router", () => {
  let caller: ReturnType<typeof appRouter.createCaller>;

  beforeAll(() => {
    const ctx = createMockContext();
    caller = appRouter.createCaller(ctx);
  }, { timeout: 30000 });

  it("should list alerts", async () => {
    const result = await caller.alerts.list();
    expect(Array.isArray(result)).toBe(true);
  }, { timeout: 30000 });
});

describe("Chat Router", () => {
  let caller: ReturnType<typeof appRouter.createCaller>;

  beforeAll(() => {
    const ctx = createMockContext();
    caller = appRouter.createCaller(ctx);
  }, { timeout: 30000 });

  it("should get chat history", async () => {
    const result = await caller.chat.history();
    expect(Array.isArray(result)).toBe(true);
  }, { timeout: 30000 });

  it("should send a message", async () => {
    const result = await caller.chat.sendMessage({
      message: "What are my spending patterns?",
    });

    expect(result).toBeDefined();
    expect(result.message).toBeDefined();
  }, { timeout: 30000 });
});
