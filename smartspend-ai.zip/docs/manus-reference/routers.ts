import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { InsertSubscription, InsertAlert, InsertChatMessage } from "../drizzle/schema";
import { invokeLLM } from "./_core/llm";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  subscriptions: router({
    list: protectedProcedure.query(({ ctx }) => 
      db.getUserSubscriptions(ctx.user.id)
    ),
    
    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(({ ctx, input }) => 
        db.getSubscriptionById(input.id, ctx.user.id)
      ),
    
    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1),
        description: z.string().optional(),
        amount: z.number().positive(),
        currency: z.string().default("USD"),
        billingFrequency: z.enum(["daily", "weekly", "monthly", "quarterly", "yearly"]),
        category: z.string().min(1),
        nextBillingDate: z.date(),
        isFreeTrialActive: z.boolean().optional(),
        trialEndDate: z.date().optional(),
        notes: z.string().optional(),
      }))
      .mutation(({ ctx, input }) => {
        const data: InsertSubscription = {
          userId: ctx.user.id,
          ...input,
        } as any;
        return db.createSubscription(data);
      }),
    
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().min(1).optional(),
        description: z.string().optional(),
        amount: z.number().positive().optional(),
        currency: z.string().optional(),
        billingFrequency: z.enum(["daily", "weekly", "monthly", "quarterly", "yearly"]).optional(),
        category: z.string().optional(),
        nextBillingDate: z.date().optional(),
        isActive: z.boolean().optional(),
        isFreeTrialActive: z.boolean().optional(),
        trialEndDate: z.date().optional(),
        notes: z.string().optional(),
      }))
      .mutation(({ ctx, input }) => {
        const { id, ...updateData } = input;
        // Type cast for Drizzle decimal handling
        return db.updateSubscription(id, ctx.user.id, updateData as any);
      }),
    
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ ctx, input }) => 
        db.deleteSubscription(input.id, ctx.user.id)
      ),
  }),

  alerts: router({
    list: protectedProcedure.query(({ ctx }) => 
      db.getUserAlerts(ctx.user.id)
    ),
    
    markAsRead: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ ctx, input }) => 
        db.markAlertAsRead(input.id, ctx.user.id)
      ),
    
    dismiss: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ ctx, input }) => 
        db.dismissAlert(input.id, ctx.user.id)
      ),
  }),

  chat: router({
    history: protectedProcedure.query(({ ctx }) => 
      db.getChatHistory(ctx.user.id)
    ),
    
    sendMessage: protectedProcedure
      .input(z.object({ message: z.string().min(1) }))
      .mutation(async ({ ctx, input }) => {
        // Save user message
        await db.saveChatMessage({
          userId: ctx.user.id,
          role: "user",
          content: input.message,
        });

        // Get user's subscriptions for context
        const subscriptions = await db.getUserSubscriptions(ctx.user.id);
        const subscriptionContext = subscriptions
          .map(s => `${s.name}: $${s.amount}/${s.billingFrequency}`)
          .join(", ");

        // Call LLM with context
        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: `You are a helpful financial advisor specializing in subscription management. The user has the following subscriptions: ${subscriptionContext}. Provide personalized advice about their subscriptions and spending habits.`,
            },
            { role: "user", content: input.message },
          ],
        });

        const responseContent = response.choices[0]?.message.content;
        const assistantMessage = typeof responseContent === 'string' ? responseContent : "I couldn't generate a response.";

        // Save assistant response
        await db.saveChatMessage({
          userId: ctx.user.id,
          role: "assistant",
          content: assistantMessage,
        });

        return { message: assistantMessage };
      }),
  }),

  analytics: router({
    getMonthly: protectedProcedure
      .input(z.object({ month: z.string() }))
      .query(({ ctx, input }) => 
        db.getMonthlyAnalytics(ctx.user.id, input.month)
      ),
  }),

  recommendations: router({
    list: protectedProcedure.query(({ ctx }) => 
      db.getUserSavingsRecommendations(ctx.user.id)
    ),
    
    generate: protectedProcedure.mutation(async ({ ctx }) => {
      const subscriptions = await db.getUserSubscriptions(ctx.user.id);
      
      if (subscriptions.length === 0) {
        return { recommendations: [] };
      }

      const subscriptionList = subscriptions
        .map(s => `${s.name}: $${s.amount}/${s.billingFrequency}`)
        .join(", ");

      const response = await invokeLLM({
        messages: [
          {
            role: "system",
            content: "You are a financial advisor. Analyze the user's subscriptions and provide 2-3 specific, actionable recommendations to reduce spending. Format your response as JSON with an array of recommendations, each with title, description, and potentialSavings fields.",
          },
          {
            role: "user",
            content: `My subscriptions are: ${subscriptionList}. Please analyze and provide recommendations to save money.`,
          },
        ],
        response_format: {
          type: "json_schema",
          json_schema: {
            name: "recommendations",
            strict: true,
            schema: {
              type: "object",
              properties: {
                recommendations: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      title: { type: "string" },
                      description: { type: "string" },
                      potentialSavings: { type: "number" },
                    },
                    required: ["title", "description", "potentialSavings"],
                  },
                },
              },
              required: ["recommendations"],
            },
          },
        },
      });

      const responseContent = response.choices[0]?.message.content;
      if (!responseContent || typeof responseContent !== 'string') return { recommendations: [] };

      const parsed = JSON.parse(responseContent);
      const recommendations = parsed.recommendations || [];

      // Save recommendations to database
      for (const rec of recommendations) {
        await db.createSavingsRecommendation({
          userId: ctx.user.id,
          title: rec.title,
          description: rec.description,
          potentialSavings: rec.potentialSavings,
          relatedSubscriptionIds: JSON.stringify(subscriptions.map(s => s.id)),
        });
      }

      return { recommendations };
    }),
    
    archive: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ ctx, input }) => 
        db.archiveSavingsRecommendation(input.id, ctx.user.id)
      ),
  }),
});

export type AppRouter = typeof appRouter;
