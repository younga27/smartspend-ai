import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Check, Loader2, Sparkles, ShieldCheck } from "lucide-react";

const STEPS = [
  "Authenticating partner OAuth session",
  "Locating active billing agreement",
  "Submitting cancellation via vendor API",
  "Verifying confirmation receipt",
];

export function CancelAgentDialog({
  open,
  onOpenChange,
  subscriptionName,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  subscriptionName: string;
}) {
  const [step, setStep] = useState(0);
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (!open) return;
    setStep(0);
    setDone(false);
    let i = 0;
    const id = setInterval(() => {
      i++;
      if (i >= STEPS.length) {
        clearInterval(id);
        setStep(STEPS.length);
        setTimeout(() => setDone(true), 400);
      } else {
        setStep(i);
      }
    }, 850);
    return () => clearInterval(id);
  }, [open]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 font-display text-2xl">
            <Sparkles className="size-5 text-signal" />
            AI Cancellation Agent
          </DialogTitle>
          <DialogDescription>
            Deploying cancellation request for{" "}
            <span className="text-foreground font-medium">{subscriptionName}</span>
          </DialogDescription>
        </DialogHeader>

        <ul className="mt-2 space-y-3">
          {STEPS.map((label, i) => {
            const active = step === i && !done;
            const complete = step > i || done;
            return (
              <li key={label} className="flex items-center gap-3 text-sm">
                <div
                  className={`grid size-6 place-items-center rounded-full border transition-colors ${
                    complete
                      ? "border-signal bg-signal text-signal-foreground"
                      : active
                        ? "border-signal/60 text-signal"
                        : "border-hairline text-muted-foreground"
                  }`}
                >
                  {complete ? (
                    <Check className="size-3.5" />
                  ) : active ? (
                    <Loader2 className="size-3.5 animate-spin" />
                  ) : (
                    <span className="size-1.5 rounded-full bg-current" />
                  )}
                </div>
                <span className={complete || active ? "text-foreground" : "text-muted-foreground"}>
                  {label}
                </span>
              </li>
            );
          })}
        </ul>

        {done && (
          <div className="mt-2 flex items-start gap-2.5 rounded-lg border border-signal/30 bg-signal/10 p-3 text-sm animate-fade-in">
            <ShieldCheck className="size-4 mt-0.5 text-signal shrink-0" />
            <div>
              <p className="font-medium text-foreground">Cancellation confirmed.</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                Sandbox demo — no live charge has been modified.
              </p>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
