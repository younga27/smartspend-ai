import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { LayoutDashboard, MessageSquare, Sparkles, BarChart3, LogOut, Menu, Lock, Upload } from "lucide-react";
import { useState } from "react";
import { BrandProvider, useBrand } from "@/lib/brand-context";
import { BrandSwitcher } from "@/components/brand-switcher";

const NAV = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/import", label: "Bulk import", icon: Upload },
  { to: "/savings", label: "Savings finder", icon: Sparkles },
  { to: "/chat", label: "AI assistant", icon: MessageSquare },
  { to: "/analytics", label: "Analytics", icon: BarChart3 },
] as const;

export function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <BrandProvider>
      <Inner>{children}</Inner>
    </BrandProvider>
  );
}

function Inner({ children }: { children: React.ReactNode }) {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [mobileOpen, setMobileOpen] = useState(false);
  const { brand } = useBrand();

  async function handleSignOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  return (
    <div className="min-h-screen bg-background grid-bg">
      {/* Top bar */}
      <header className="sticky top-0 z-40 border-b border-hairline bg-background/80 backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 md:px-6">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileOpen((v) => !v)}
              className="md:hidden grid size-9 place-items-center rounded-md border border-hairline"
              aria-label="Toggle navigation"
            >
              <Menu className="size-4" />
            </button>
            <Link to="/" className="flex items-center gap-2.5">
              <div
                className="grid size-7 place-items-center rounded-md text-sm font-semibold transition-colors"
                style={{ background: "var(--signal)", color: "var(--signal-foreground)" }}
              >
                {brand.logoMark}
              </div>
              <span
                className="text-[15px] font-medium tracking-tight"
                style={{ fontFamily: "var(--font-display)" }}
              >
                {brand.name}
              </span>
              <span className="hidden sm:inline-flex items-center gap-1 rounded-full border border-hairline px-2 py-0.5 text-[10px] uppercase tracking-wider text-muted-foreground">
                <span className="size-1.5 rounded-full bg-signal pulse-dot" /> Live
              </span>
            </Link>
          </div>

          <Button variant="ghost" size="sm" onClick={handleSignOut}>
            <LogOut className="size-4" /> Sign out
          </Button>
        </div>
      </header>

      <div className="mx-auto flex max-w-7xl">
        {/* Sidebar */}
        <aside
          className={`${mobileOpen ? "block" : "hidden"} md:flex w-full md:w-60 shrink-0 border-r border-hairline md:min-h-[calc(100vh-4rem)] flex-col px-3 py-5`}
        >
          <BrandSwitcher />

          <nav className="mt-5 flex flex-col gap-1">
            {NAV.map((item) => {
              const active = pathname.startsWith(item.to);
              const Icon = item.icon;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  onClick={() => setMobileOpen(false)}
                  className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors ${
                    active
                      ? "bg-elevated text-foreground"
                      : "text-muted-foreground hover:bg-elevated/50 hover:text-foreground"
                  }`}
                >
                  <Icon className="size-4" />
                  {item.label}
                </Link>
              );
            })}
          </nav>

          <div className="mt-auto pt-6">
            <div className="rounded-lg border border-hairline bg-card/30 p-3">
              <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-muted-foreground">
                <Lock className="size-3" /> Secured
              </div>
              <p className="mt-1.5 text-[11px] leading-snug text-muted-foreground">
                Bank-grade encryption provided via Stripe Connect framework. SOC 2 Type II.
              </p>
            </div>
          </div>
        </aside>

        {/* Main */}
        <main className="min-w-0 flex-1 px-4 py-8 md:px-8 md:py-10">{children}</main>
      </div>
    </div>
  );
}
