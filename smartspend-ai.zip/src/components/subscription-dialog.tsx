import { useState, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { createSubscription, updateSubscription } from "@/lib/subscriptions.functions";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";

type SubscriptionRow = {
  id: string;
  name: string;
  description: string | null;
  amount: number | string;
  currency: string;
  billing_frequency: "daily" | "weekly" | "monthly" | "quarterly" | "yearly";
  category: string;
  next_billing_date: string;
  notes: string | null;
};

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  subscription?: SubscriptionRow | null;
}

const CATEGORIES = [
  "streaming",
  "software",
  "productivity",
  "fitness",
  "news",
  "music",
  "gaming",
  "education",
  "utilities",
  "other",
];

export function SubscriptionDialog({ open, onOpenChange, subscription }: Props) {
  const isEdit = !!subscription;
  const qc = useQueryClient();
  const createFn = useServerFn(createSubscription);
  const updateFn = useServerFn(updateSubscription);

  const [form, setForm] = useState({
    name: "",
    amount: "",
    currency: "USD",
    billing_frequency: "monthly" as SubscriptionRow["billing_frequency"],
    category: "software",
    next_billing_date: new Date().toISOString().slice(0, 10),
    notes: "",
  });

  useEffect(() => {
    if (subscription) {
      setForm({
        name: subscription.name,
        amount: String(subscription.amount),
        currency: subscription.currency,
        billing_frequency: subscription.billing_frequency,
        category: subscription.category,
        next_billing_date: subscription.next_billing_date,
        notes: subscription.notes ?? "",
      });
    } else {
      setForm({
        name: "",
        amount: "",
        currency: "USD",
        billing_frequency: "monthly",
        category: "software",
        next_billing_date: new Date().toISOString().slice(0, 10),
        notes: "",
      });
    }
  }, [subscription, open]);

  const mutation = useMutation({
    mutationFn: async () => {
      const payload = {
        name: form.name,
        amount: parseFloat(form.amount),
        currency: form.currency,
        billing_frequency: form.billing_frequency,
        category: form.category,
        next_billing_date: form.next_billing_date,
        notes: form.notes || null,
      };
      if (isEdit && subscription) {
        return updateFn({ data: { id: subscription.id, ...payload } });
      }
      return createFn({ data: payload });
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["subscriptions"] });
      toast.success(isEdit ? "Subscription updated" : "Subscription added");
      onOpenChange(false);
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed to save"),
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl">
            {isEdit ? "Edit subscription" : "Add subscription"}
          </DialogTitle>
          <DialogDescription>
            Track a recurring charge to see it in your dashboard.
          </DialogDescription>
        </DialogHeader>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            mutation.mutate();
          }}
          className="space-y-4"
        >
          <div className="space-y-1.5">
            <Label htmlFor="name">Name</Label>
            <Input
              id="name"
              required
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              placeholder="Netflix"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="amount">Amount</Label>
              <Input
                id="amount"
                type="number"
                step="0.01"
                min="0"
                required
                value={form.amount}
                onChange={(e) => setForm({ ...form, amount: e.target.value })}
                placeholder="15.99"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Frequency</Label>
              <Select
                value={form.billing_frequency}
                onValueChange={(v) => setForm({ ...form, billing_frequency: v as SubscriptionRow["billing_frequency"] })}
              >
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                  <SelectItem value="quarterly">Quarterly</SelectItem>
                  <SelectItem value="yearly">Yearly</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Category</Label>
              <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((c) => (
                    <SelectItem key={c} value={c} className="capitalize">{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="next">Next billing</Label>
              <Input
                id="next"
                type="date"
                required
                value={form.next_billing_date}
                onChange={(e) => setForm({ ...form, next_billing_date: e.target.value })}
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              rows={2}
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
              placeholder="Optional"
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={mutation.isPending}
              className="bg-signal text-signal-foreground hover:opacity-90"
            >
              {mutation.isPending && <Loader2 className="size-4 animate-spin" />}
              {isEdit ? "Save" : "Add subscription"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
