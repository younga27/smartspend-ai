import { BRANDS, useBrand } from "@/lib/brand-context";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuLabel,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { Check, ChevronsUpDown, Palette } from "lucide-react";

export function BrandSwitcher() {
  const { brand, setBrandId } = useBrand();
  return (
    <DropdownMenu>
      <DropdownMenuTrigger className="group flex w-full items-center gap-2.5 rounded-lg border border-hairline bg-card/40 px-3 py-2.5 text-left transition-colors hover:bg-elevated/60">
        <div
          className="grid size-8 shrink-0 place-items-center rounded-md text-sm font-semibold"
          style={{ background: "var(--signal)", color: "var(--signal-foreground)" }}
        >
          {brand.logoMark}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-muted-foreground">
            <Palette className="size-3" /> Partner brand
          </div>
          <div className="truncate text-sm font-medium" style={{ fontFamily: "var(--font-display)" }}>
            {brand.name}
          </div>
        </div>
        <ChevronsUpDown className="size-3.5 shrink-0 text-muted-foreground" />
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-64">
        <DropdownMenuLabel className="text-[10px] uppercase tracking-wider text-muted-foreground">
          Preview white-label theme
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        {BRANDS.map((b) => (
          <DropdownMenuItem
            key={b.id}
            onClick={() => setBrandId(b.id)}
            className="flex items-center gap-2.5"
          >
            <div
              className="grid size-7 shrink-0 place-items-center rounded-md text-xs font-semibold"
              style={{ background: b.signal, color: b.signalFg }}
            >
              {b.logoMark}
            </div>
            <div className="min-w-0 flex-1">
              <div className="truncate text-sm" style={{ fontFamily: b.fontDisplay }}>
                {b.name}
              </div>
              <div className="truncate text-[11px] text-muted-foreground">{b.tagline}</div>
            </div>
            {brand.id === b.id && <Check className="size-3.5 text-signal" />}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
