import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  listRecommendations,
  generateRecommendations,
  archiveRecommendation,
} from "@/lib/recommendations.functions";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Sparkles, Loader2, X, TrendingDown } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/savings")({
  head: () => ({ meta: [{ title: "Savings Finder — SmartSpend AI" }] }),
  component: SavingsPage,
});

function SavingsPage() {
  const qc = useQueryClient();
  const listFn = useServerFn(listRecommendations);
  const genFn = useServerFn(generateRecommendations);
  const archiveFn = useServerFn(archiveRecommendation);

  const { data: recs = [], isLoading } = useQuery({
    queryKey: ["recommendations"],
    queryFn: () => listFn(),
  });

  const generate = useMutation({
    mutationFn: () => genFn(),
    onSuccess: (res) => {
      if (res.message) toast.message(res.message);
      else toast.success(`Generated ${res.recommendations.length} ideas`);
      qc.invalidateQueries({ queryKey: ["recommendations"] });
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const archive = useMutation({
    mutationFn: (id: string) => archiveFn({ data: { id } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["recommendations"] }),
  });

  const totalSavings = recs.reduce(
    (s, r) => s + (typeof r.potential_savings === "string" ? parseFloat(r.potential_savings) : Number(r.potential_savings)),
    0,
  );

  return (
    <AppShell>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-5xl leading-none tracking-tight">Savings Finder</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            AI-curated ways to cut your monthly outlay, grounded in your real subscriptions.
          </p>
        </div>
        <Button
          onClick={() => generate.mutate()}
          disabled={generate.isPending}
          className="bg-signal text-signal-foreground hover:opacity-90 h-10"
        >
          {generate.isPending ? <Loader2 className="size-4 animate-spin" /> : <Sparkles className="size-4" />}
          {generate.isPending ? "Analysing…" : "Generate ideas"}
        </Button>
      </div>

      {recs.length > 0 && (
        <div className="mt-8 rounded-2xl border border-hairline bg-gradient-to-br from-signal/10 to-transparent p-6">
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Potential monthly savings</div>
          <div className="mt-2 flex items-baseline gap-3">
            <span className="font-display text-5xl tabular-nums text-signal">
              ${totalSavings.toFixed(0)}
            </span>
            <span className="text-sm text-muted-foreground">
              · ${(totalSavings * 12).toFixed(0)}/year
            </span>
          </div>
        </div>
      )}

      <div className="mt-8 grid gap-4 md:grid-cols-2">
        {isLoading ? (
          <p className="text-sm text-muted-foreground">Loading…</p>
        ) : recs.length === 0 ? (
          <div className="md:col-span-2 rounded-2xl border border-hairline bg-card/40 p-10 text-center">
            <div className="mx-auto grid size-12 place-items-center rounded-full bg-signal/15 text-signal">
              <Sparkles className="size-5" />
            </div>
            <p className="mt-4 font-display text-2xl">No recommendations yet</p>
            <p className="mt-1 text-sm text-muted-foreground">
              Click <span className="text-foreground">Generate ideas</span> and the assistant will analyse your subscriptions.
            </p>
          </div>
        ) : (
          recs.map((r) => {
            const savings = typeof r.potential_savings === "string" ? parseFloat(r.potential_savings) : Number(r.potential_savings);
            return (
              <div
                key={r.id}
                className="group relative rounded-2xl border border-hairline bg-card/40 p-5 transition-colors hover:bg-card/60"
              >
                <button
                  onClick={() => archive.mutate(r.id)}
                  className="absolute right-3 top-3 grid size-7 place-items-center rounded-md text-muted-foreground opacity-0 transition-opacity hover:bg-elevated hover:text-foreground group-hover:opacity-100"
                  aria-label="Dismiss"
                >
                  <X className="size-3.5" />
                </button>
                <div className="flex items-center gap-2 text-xs text-signal">
                  <TrendingDown className="size-3.5" />
                  <span className="font-mono tabular-nums">${savings.toFixed(0)}/mo</span>
                </div>
                <h3 className="mt-2 font-display text-xl leading-tight">{r.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{r.description}</p>
              </div>
            );
          })
        )}
      </div>
    </AppShell>
  );
}
