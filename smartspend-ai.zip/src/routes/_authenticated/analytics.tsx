import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listSubscriptions } from "@/lib/subscriptions.functions";
import { AppShell } from "@/components/app-shell";
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from "recharts";

export const Route = createFileRoute("/_authenticated/analytics")({
  head: () => ({ meta: [{ title: "Analytics — SmartSpend AI" }] }),
  component: AnalyticsPage,
});

type Sub = Awaited<ReturnType<typeof listSubscriptions>>[number];

function monthly(s: Sub): number {
  const amt = typeof s.amount === "string" ? parseFloat(s.amount) : (s.amount as number);
  switch (s.billing_frequency) {
    case "daily": return amt * 30;
    case "weekly": return amt * 4.33;
    case "monthly": return amt;
    case "quarterly": return amt / 3;
    case "yearly": return amt / 12;
  }
}

const COLORS = ["#a8ff60", "#7dd3fc", "#fbbf24", "#f472b6", "#c084fc", "#34d399", "#fb923c", "#94a3b8"];

function AnalyticsPage() {
  const listFn = useServerFn(listSubscriptions);
  const { data: subs = [], isLoading } = useQuery({
    queryKey: ["subscriptions"],
    queryFn: () => listFn(),
  });

  const active = subs.filter((s) => s.is_active);

  // Category breakdown
  const byCategoryMap = new Map<string, number>();
  for (const s of active) {
    byCategoryMap.set(s.category, (byCategoryMap.get(s.category) ?? 0) + monthly(s));
  }
  const byCategory = Array.from(byCategoryMap.entries())
    .map(([name, value]) => ({ name, value: Math.round(value * 100) / 100 }))
    .sort((a, b) => b.value - a.value);

  // Top subscriptions by monthly cost
  const topSubs = [...active]
    .map((s) => ({ name: s.name, value: Math.round(monthly(s) * 100) / 100 }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 8);

  // Frequency mix
  const freqMap = new Map<string, number>();
  for (const s of active) {
    freqMap.set(s.billing_frequency, (freqMap.get(s.billing_frequency) ?? 0) + 1);
  }
  const freqMix = Array.from(freqMap.entries()).map(([name, value]) => ({ name, value }));

  const totalMonthly = active.reduce((sum, s) => sum + monthly(s), 0);
  const avgPerSub = active.length > 0 ? totalMonthly / active.length : 0;

  return (
    <AppShell>
      <div>
        <h1 className="font-display text-5xl leading-none tracking-tight">Analytics</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Where your recurring spend goes — broken down across categories, services, and cadence.
        </p>
      </div>

      <div className="mt-8 grid gap-4 md:grid-cols-3">
        <StatCard label="Monthly outlay" value={`$${totalMonthly.toFixed(2)}`} sub={`${active.length} active`} />
        <StatCard label="Average / subscription" value={`$${avgPerSub.toFixed(2)}`} sub="per month" />
        <StatCard label="Largest category" value={byCategory[0]?.name ?? "—"} sub={byCategory[0] ? `$${byCategory[0].value.toFixed(0)}/mo` : ""} />
      </div>

      {isLoading ? (
        <p className="mt-10 text-sm text-muted-foreground">Loading…</p>
      ) : active.length === 0 ? (
        <div className="mt-10 rounded-2xl border border-hairline bg-card/40 p-10 text-center">
          <p className="font-display text-2xl">No data yet</p>
          <p className="mt-1 text-sm text-muted-foreground">Add subscriptions on the dashboard to populate analytics.</p>
        </div>
      ) : (
        <div className="mt-8 grid gap-6 lg:grid-cols-2">
          <ChartCard title="By category" subtitle="Monthly spend share">
            <ResponsiveContainer width="100%" height={280}>
              <PieChart>
                <Pie data={byCategory} dataKey="value" nameKey="name" innerRadius={60} outerRadius={100} paddingAngle={2}>
                  {byCategory.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ background: "hsl(0 0% 10%)", border: "1px solid hsl(0 0% 20%)", borderRadius: 8, fontSize: 12 }}
                  formatter={(v: number) => `$${v.toFixed(2)}/mo`}
                />
              </PieChart>
            </ResponsiveContainer>
            <ul className="mt-2 grid grid-cols-2 gap-1.5 text-xs">
              {byCategory.map((c, i) => (
                <li key={c.name} className="flex items-center gap-2">
                  <span className="size-2 rounded-sm" style={{ background: COLORS[i % COLORS.length] }} />
                  <span className="truncate capitalize text-muted-foreground">{c.name}</span>
                  <span className="ml-auto font-mono tabular-nums">${c.value.toFixed(0)}</span>
                </li>
              ))}
            </ul>
          </ChartCard>

          <ChartCard title="Top subscriptions" subtitle="Monthly cost">
            <ResponsiveContainer width="100%" height={320}>
              <BarChart data={topSubs} layout="vertical" margin={{ left: 10, right: 16, top: 8, bottom: 8 }}>
                <CartesianGrid stroke="hsl(0 0% 20%)" strokeDasharray="2 4" horizontal={false} />
                <XAxis type="number" stroke="hsl(0 0% 50%)" fontSize={11} tickFormatter={(v) => `$${v}`} />
                <YAxis type="category" dataKey="name" stroke="hsl(0 0% 70%)" fontSize={11} width={90} />
                <Tooltip
                  contentStyle={{ background: "hsl(0 0% 10%)", border: "1px solid hsl(0 0% 20%)", borderRadius: 8, fontSize: 12 }}
                  formatter={(v: number) => `$${v.toFixed(2)}/mo`}
                />
                <Bar dataKey="value" fill="#a8ff60" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>

          <ChartCard title="Billing cadence" subtitle="Subscription count by frequency">
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={freqMix}>
                <CartesianGrid stroke="hsl(0 0% 20%)" strokeDasharray="2 4" vertical={false} />
                <XAxis dataKey="name" stroke="hsl(0 0% 50%)" fontSize={11} />
                <YAxis stroke="hsl(0 0% 50%)" fontSize={11} allowDecimals={false} />
                <Tooltip contentStyle={{ background: "hsl(0 0% 10%)", border: "1px solid hsl(0 0% 20%)", borderRadius: 8, fontSize: 12 }} />
                <Bar dataKey="value" fill="#7dd3fc" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>

          <ChartCard title="Annualised projection" subtitle="What this looks like over 12 months">
            <div className="grid h-full place-items-center">
              <div className="text-center">
                <div className="font-display text-6xl tabular-nums text-signal">${(totalMonthly * 12).toFixed(0)}</div>
                <p className="mt-2 text-xs text-muted-foreground">per year at current run rate</p>
                <div className="mt-6 grid grid-cols-2 gap-6 text-left">
                  <div>
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Quarter</div>
                    <div className="font-mono text-lg tabular-nums">${(totalMonthly * 3).toFixed(0)}</div>
                  </div>
                  <div>
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Decade</div>
                    <div className="font-mono text-lg tabular-nums">${(totalMonthly * 120).toFixed(0)}</div>
                  </div>
                </div>
              </div>
            </div>
          </ChartCard>
        </div>
      )}
    </AppShell>
  );
}

function StatCard({ label, value, sub }: { label: string; value: string; sub: string }) {
  return (
    <div className="rounded-2xl border border-hairline bg-card/40 p-5">
      <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="mt-3 font-display text-4xl leading-none tabular-nums">{value}</div>
      <p className="mt-2 text-xs text-muted-foreground">{sub}</p>
    </div>
  );
}

function ChartCard({ title, subtitle, children }: { title: string; subtitle: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-hairline bg-card/40 p-5">
      <div className="mb-4">
        <h3 className="text-sm font-medium">{title}</h3>
        <p className="text-xs text-muted-foreground">{subtitle}</p>
      </div>
      {children}
    </div>
  );
}
