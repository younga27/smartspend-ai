import { createFileRoute, Link } from "@tanstack/react-router";
import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listSubscriptions, deleteSubscription } from "@/lib/subscriptions.functions";
import { SubscriptionDialog } from "@/components/subscription-dialog";
import { CancelAgentDialog } from "@/components/cancel-agent-dialog";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { format, differenceInDays, parseISO } from "date-fns";
import {
  Plus,
  TrendingDown,
  Bell,
  CreditCard,
  MoreHorizontal,
  Sparkles,
  ArrowUpRight,
  Flame,
  Zap,
  Lock,
} from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — SmartSpend AI" }] }),
  component: DashboardPage,
});

type Sub = Awaited<ReturnType<typeof listSubscriptions>>[number];

function monthlyAmount(s: Sub): number {
  const amt = typeof s.amount === "string" ? parseFloat(s.amount) : (s.amount as number);
  switch (s.billing_frequency) {
    case "daily": return amt * 30;
    case "weekly": return amt * 4.33;
    case "monthly": return amt;
    case "quarterly": return amt / 3;
    case "yearly": return amt / 12;
  }
}

// Heuristic: a "leak" = inactive sub still on file, or overdue renewal, or 'entertainment'/'software' under low usage proxy
function isLeak(s: Sub, today: Date): boolean {
  if (!s.is_active) return true;
  const days = differenceInDays(parseISO(s.next_billing_date), today);
  if (days < 0) return true; // overdue trial
  return false;
}

function statusFor(s: Sub, today: Date): { label: string; tone: "active" | "renew" | "leak"; dot: string } {
  const days = differenceInDays(parseISO(s.next_billing_date), today);
  if (!s.is_active || days < 0) return { label: "Trial Overdue", tone: "leak", dot: "🔴" };
  if (days <= 7) return { label: "Upcoming Renewal", tone: "renew", dot: "🟡" };
  return { label: "Active", tone: "active", dot: "🟢" };
}

function DashboardPage() {
  const qc = useQueryClient();
  const listFn = useServerFn(listSubscriptions);
  const deleteFn = useServerFn(deleteSubscription);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Sub | null>(null);
  const [cancelTarget, setCancelTarget] = useState<string | null>(null);
  const [view, setView] = useState<"all" | "optimized">("all");

  const { data: subs = [], isLoading } = useQuery({
    queryKey: ["subscriptions"],
    queryFn: () => listFn(),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => deleteFn({ data: { id } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["subscriptions"] });
      toast.success("Subscription removed");
    },
  });

  const today = useMemo(() => new Date(), []);

  const totalMonthly = subs.reduce((sum, s) => sum + monthlyAmount(s), 0);
  const totalYearly = totalMonthly * 12;
  const activeCount = subs.filter((s) => s.is_active).length;

  const leakSubs = subs.filter((s) => isLeak(s, today));
  const leakMonthly = leakSubs.reduce((sum, s) => sum + monthlyAmount(s), 0);

  const optimizedMonthly = totalMonthly - leakMonthly;
  const realized = view === "optimized" ? optimizedMonthly : totalMonthly;

  const displaySubs = view === "optimized"
    ? subs.filter((s) => !isLeak(s, today))
    : subs;

  const upcoming = [...subs]
    .filter((s) => s.is_active)
    .sort((a, b) => a.next_billing_date.localeCompare(b.next_billing_date))
    .slice(0, 5);

  const renewSoon = subs.filter((s) => {
    const days = differenceInDays(parseISO(s.next_billing_date), today);
    return s.is_active && days >= 0 && days <= 7;
  });

  return (
    <AppShell>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-5xl leading-none tracking-tight">Dashboard</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            An institutional view of every recurring charge.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <ToggleView view={view} setView={setView} />
          <Button
            onClick={() => { setEditing(null); setDialogOpen(true); }}
            className="bg-signal text-signal-foreground hover:opacity-90 h-10"
          >
            <Plus className="size-4" /> Add subscription
          </Button>
        </div>
      </div>

      <div className="mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <MetricCard
          label={view === "optimized" ? "Optimized monthly" : "Monthly outlay"}
          value={`$${realized.toFixed(2)}`}
          sub={
            view === "optimized"
              ? `Saved $${leakMonthly.toFixed(2)}/mo vs. baseline`
              : `${activeCount} active subscription${activeCount === 1 ? "" : "s"}`
          }
          icon={CreditCard}
        />
        <MetricCard
          label="Annualised"
          value={`$${(realized * 12).toFixed(0)}`}
          sub="Projected 12-month spend"
          icon={TrendingDown}
        />
        <MetricCard
          label="Renews this week"
          value={String(renewSoon.length)}
          sub={renewSoon.length ? "Within the next 7 days" : "Nothing urgent"}
          icon={Bell}
          accent={renewSoon.length > 0}
        />
        <LeakCard count={leakSubs.length} monthly={leakMonthly} />
      </div>

      <section className="mt-10 grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 rounded-2xl border border-hairline bg-card/40">
          <div className="flex items-center justify-between border-b border-hairline px-5 py-4">
            <div>
              <h2 className="text-sm font-medium">
                {view === "optimized" ? "Optimized subscriptions" : "All subscriptions"}
              </h2>
              <p className="text-xs text-muted-foreground">
                {view === "optimized"
                  ? "Cash leaks removed — your post-AI baseline"
                  : "Sorted by next billing date"}
              </p>
            </div>
          </div>

          {isLoading ? (
            <GhostList />
          ) : displaySubs.length === 0 ? (
            <EmptyState onAdd={() => { setEditing(null); setDialogOpen(true); }} />
          ) : (
            <ul className="divide-y divide-hairline">
              {displaySubs.map((s) => {
                const amt = typeof s.amount === "string" ? parseFloat(s.amount) : (s.amount as number);
                const status = statusFor(s, today);
                return (
                  <li key={s.id} className="flex items-center gap-4 px-5 py-4 transition-colors hover:bg-elevated/40">
                    <div className="grid size-10 place-items-center rounded-md bg-elevated text-foreground font-display text-lg">
                      {s.name.charAt(0).toUpperCase()}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <p className="truncate font-medium">{s.name}</p>
                        <StatusTag status={status} />
                        <span className="rounded-full border border-hairline px-1.5 py-0.5 text-[10px] capitalize text-muted-foreground">
                          {s.category}
                        </span>
                      </div>
                      <p className="mt-0.5 text-xs text-muted-foreground flex items-center gap-1.5">
                        <Lock className="size-2.5" />
                        Renews {format(parseISO(s.next_billing_date), "MMM d, yyyy")} · {s.billing_frequency}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-mono tabular-nums">${amt.toFixed(2)}</p>
                      <p className="text-[10px] text-muted-foreground">
                        ${monthlyAmount(s).toFixed(2)}/mo
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="h-8 hidden sm:inline-flex border-signal/40 text-signal hover:bg-signal/10 hover:text-signal"
                      onClick={() => setCancelTarget(s.name)}
                    >
                      <Zap className="size-3" /> Cancel for me
                    </Button>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="size-8">
                          <MoreHorizontal className="size-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => setCancelTarget(s.name)}>
                          <Zap className="size-3.5" /> Cancel via AI agent
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => { setEditing(s); setDialogOpen(true); }}>
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          className="text-destructive focus:text-destructive"
                          onClick={() => deleteMutation.mutate(s.id)}
                        >
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </li>
                );
              })}
            </ul>
          )}
        </div>

        <div className="space-y-6">
          <div className="rounded-2xl border border-hairline bg-card/40 p-5">
            <div className="flex items-center gap-2 text-sm font-medium">
              <Bell className="size-4 text-signal" /> Upcoming renewals
            </div>
            <ul className="mt-4 space-y-3">
              {upcoming.length === 0 ? (
                <li className="text-xs text-muted-foreground">No upcoming renewals.</li>
              ) : (
                upcoming.map((s) => {
                  const days = differenceInDays(parseISO(s.next_billing_date), today);
                  const amt = typeof s.amount === "string" ? parseFloat(s.amount) : (s.amount as number);
                  return (
                    <li key={s.id} className="flex items-center justify-between gap-3 text-sm">
                      <div className="min-w-0">
                        <p className="truncate">{s.name}</p>
                        <p className="text-[11px] text-muted-foreground">
                          {days === 0 ? "Today" : days < 0 ? "Overdue" : `in ${days}d`}
                        </p>
                      </div>
                      <p className="font-mono text-xs tabular-nums">${amt.toFixed(2)}</p>
                    </li>
                  );
                })
              )}
            </ul>
          </div>

          <div className="rounded-2xl border border-hairline bg-gradient-to-br from-signal/10 to-transparent p-5">
            <div className="flex items-center gap-2 text-sm font-medium">
              <Sparkles className="size-4 text-signal" /> AI Savings finder
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              Personalised recommendations using your real subscription data.
            </p>
            <Link
              to="/savings"
              className="mt-4 inline-flex items-center gap-1 text-xs text-signal hover:underline"
            >
              Generate recommendations <ArrowUpRight className="size-3" />
            </Link>
          </div>

          <div className="rounded-2xl border border-hairline bg-card/40 p-5">
            <div className="flex items-center gap-2 text-sm font-medium">
              <Lock className="size-4 text-signal" /> Bank connections
            </div>
            <ul className="mt-3 space-y-2 text-xs text-muted-foreground">
              <li className="flex items-center justify-between rounded-md bg-elevated/40 px-2.5 py-1.5">
                <span className="flex items-center gap-2"><Lock className="size-3 text-signal" /> Chase ••4821</span>
                <span className="text-signal">Encrypted</span>
              </li>
              <li className="flex items-center justify-between rounded-md bg-elevated/40 px-2.5 py-1.5">
                <span className="flex items-center gap-2"><Lock className="size-3 text-signal" /> Amex ••0019</span>
                <span className="text-signal">Encrypted</span>
              </li>
            </ul>
            <p className="mt-3 text-[10px] leading-snug text-muted-foreground">
              Bank-grade encryption provided via Stripe Connect framework.
            </p>
          </div>
        </div>
      </section>

      <SubscriptionDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        subscription={editing}
      />
      <CancelAgentDialog
        open={!!cancelTarget}
        onOpenChange={(v) => !v && setCancelTarget(null)}
        subscriptionName={cancelTarget ?? ""}
      />
    </AppShell>
  );
}

function ToggleView({ view, setView }: { view: "all" | "optimized"; setView: (v: "all" | "optimized") => void }) {
  return (
    <div className="inline-flex items-center rounded-lg border border-hairline bg-card/40 p-0.5 text-xs">
      <button
        onClick={() => setView("all")}
        className={`px-3 py-1.5 rounded-md transition-colors ${
          view === "all" ? "bg-elevated text-foreground" : "text-muted-foreground hover:text-foreground"
        }`}
      >
        All subscriptions
      </button>
      <button
        onClick={() => setView("optimized")}
        className={`px-3 py-1.5 rounded-md transition-colors flex items-center gap-1 ${
          view === "optimized" ? "bg-signal text-signal-foreground" : "text-muted-foreground hover:text-foreground"
        }`}
      >
        <Sparkles className="size-3" /> Optimized savings
      </button>
    </div>
  );
}

function StatusTag({ status }: { status: ReturnType<typeof statusFor> }) {
  const cls =
    status.tone === "active"
      ? "border-signal/40 text-signal bg-signal/10"
      : status.tone === "renew"
        ? "border-yellow-500/40 text-yellow-400 bg-yellow-500/10"
        : "border-red-500/40 text-red-400 bg-red-500/10";
  return (
    <span className={`inline-flex items-center gap-1 rounded-full border px-1.5 py-0.5 text-[10px] ${cls}`}>
      <span className="size-1.5 rounded-full bg-current" />
      {status.label}
    </span>
  );
}

function LeakCard({ count, monthly }: { count: number; monthly: number }) {
  return (
    <div className="relative overflow-hidden rounded-2xl border border-red-500/30 bg-gradient-to-br from-red-500/10 via-card/40 to-transparent p-5">
      <div className="flex items-center justify-between text-xs">
        <span className="uppercase tracking-wider text-red-400 font-medium">Active Cash Leaks</span>
        <Flame className="size-4 text-red-400" />
      </div>
      <div className="mt-3 font-display text-4xl leading-none tracking-tight tabular-nums text-red-400">
        ${monthly.toFixed(2)}
      </div>
      <p className="mt-2 text-xs text-muted-foreground">
        {count} forgotten or overdue line item{count === 1 ? "" : "s"} / mo
      </p>
    </div>
  );
}

function MetricCard({
  label,
  value,
  sub,
  icon: Icon,
  accent,
}: {
  label: string;
  value: string;
  sub: string;
  icon: React.ComponentType<{ className?: string }>;
  accent?: boolean;
}) {
  return (
    <div className={`rounded-2xl border border-hairline bg-card/40 p-5 ${accent ? "ring-1 ring-signal/40" : ""}`}>
      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <span className="uppercase tracking-wider">{label}</span>
        <Icon className="size-4" />
      </div>
      <div className="mt-3 font-display text-4xl leading-none tracking-tight tabular-nums">{value}</div>
      <p className="mt-2 text-xs text-muted-foreground">{sub}</p>
    </div>
  );
}

function GhostList() {
  return (
    <div className="p-5">
      <p className="mb-4 flex items-center gap-2 text-xs text-muted-foreground">
        <Sparkles className="size-3 text-signal animate-pulse" />
        Analyzing statements...
      </p>
      <ul className="space-y-3">
        {[...Array(5)].map((_, i) => (
          <li key={i} className="flex items-center gap-4 animate-pulse" style={{ animationDelay: `${i * 80}ms` }}>
            <div className="size-10 rounded-md bg-elevated" />
            <div className="flex-1 space-y-2">
              <div className="h-3 w-1/3 rounded bg-elevated" />
              <div className="h-2 w-1/2 rounded bg-elevated/60" />
            </div>
            <div className="h-3 w-14 rounded bg-elevated" />
          </li>
        ))}
      </ul>
    </div>
  );
}

function EmptyState({ onAdd }: { onAdd: () => void }) {
  return (
    <div className="relative p-10 text-center">
      {/* Ghost chart */}
      <svg viewBox="0 0 400 100" className="mx-auto mb-6 w-full max-w-sm opacity-20" aria-hidden>
        <defs>
          <linearGradient id="g" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor="var(--signal)" stopOpacity="0.6" />
            <stop offset="100%" stopColor="var(--signal)" stopOpacity="0" />
          </linearGradient>
        </defs>
        <path
          d="M0,80 C40,60 80,70 120,50 C160,30 200,55 240,40 C280,25 320,45 360,30 L400,25 L400,100 L0,100 Z"
          fill="url(#g)"
        />
        <path
          d="M0,80 C40,60 80,70 120,50 C160,30 200,55 240,40 C280,25 320,45 360,30 L400,25"
          fill="none"
          stroke="var(--signal)"
          strokeWidth="1.5"
        />
      </svg>
      <div className="mx-auto grid size-12 place-items-center rounded-full bg-elevated">
        <CreditCard className="size-5 text-muted-foreground" />
      </div>
      <p className="mt-4 font-display text-2xl">Analyzing statements...</p>
      <p className="mt-1 text-sm text-muted-foreground">
        Add your first recurring charge to bring this dashboard to life.
      </p>
      <Button onClick={onAdd} className="mt-5 bg-signal text-signal-foreground hover:opacity-90">
        <Plus className="size-4" /> Add subscription
      </Button>
    </div>
  );
}
