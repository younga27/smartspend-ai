import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listChatMessages, sendChatMessage, clearChatHistory } from "@/lib/chat.functions";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Send, Loader2, Sparkles, Trash2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/chat")({
  head: () => ({ meta: [{ title: "AI Assistant — SmartSpend AI" }] }),
  component: ChatPage,
});

type Msg = { id: string; role: string; content: string; created_at: string };

const SUGGESTIONS = [
  "Where am I losing the most money?",
  "Find duplicate software trials",
  "Which subscription should I cancel first?",
  "Show me $50 of monthly savings",
];

const QUICK_PROMPTS = [
  "Where am I losing the most money?",
  "Find duplicate software trials",
  "Summarize this month's renewals",
];

function ChatPage() {
  const qc = useQueryClient();
  const listFn = useServerFn(listChatMessages);
  const sendFn = useServerFn(sendChatMessage);
  const clearFn = useServerFn(clearChatHistory);

  const [input, setInput] = useState("");
  const [pending, setPending] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const { data: messages = [] } = useQuery<Msg[]>({
    queryKey: ["chat-messages"],
    queryFn: () => listFn(),
  });

  const sendMutation = useMutation({
    mutationFn: (message: string) => sendFn({ data: { message } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["chat-messages"] });
      setPending(null);
    },
    onError: (err: Error) => {
      toast.error(err.message);
      setPending(null);
    },
  });

  const clearMutation = useMutation({
    mutationFn: () => clearFn(),
    onSuccess: () => {
      qc.setQueryData(["chat-messages"], []);
      toast.success("Conversation cleared");
    },
  });

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, pending]);

  useEffect(() => {
    textareaRef.current?.focus();
  }, []);

  function submit(text: string) {
    const t = text.trim();
    if (!t || sendMutation.isPending) return;
    setPending(t);
    setInput("");
    sendMutation.mutate(t);
    requestAnimationFrame(() => textareaRef.current?.focus());
  }

  function handleKey(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      submit(input);
    }
  }

  const hasHistory = messages.length > 0 || pending;

  return (
    <AppShell>
      <div className="mx-auto flex h-[calc(100vh-8rem)] max-w-3xl flex-col">
        <div className="flex items-end justify-between gap-4 pb-4">
          <div>
            <h1 className="font-display text-4xl leading-none tracking-tight">AI Assistant</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              A financial advisor that knows your subscriptions inside out.
            </p>
          </div>
          {messages.length > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => clearMutation.mutate()}
              disabled={clearMutation.isPending}
            >
              <Trash2 className="size-4" /> Clear
            </Button>
          )}
        </div>

        <div className="flex-1 overflow-y-auto rounded-2xl border border-hairline bg-card/30 p-5">
          {!hasHistory ? (
            <div className="flex h-full flex-col items-center justify-center text-center">
              <div className="grid size-12 place-items-center rounded-full bg-signal/15 text-signal">
                <Sparkles className="size-5" />
              </div>
              <h3 className="mt-4 font-display text-2xl">How can I help?</h3>
              <p className="mt-1 max-w-md text-sm text-muted-foreground">
                Ask anything about your subscriptions or spending. I'll use your live data.
              </p>
              <div className="mt-6 grid w-full max-w-md gap-2">
                {SUGGESTIONS.map((s) => (
                  <button
                    key={s}
                    onClick={() => submit(s)}
                    className="rounded-lg border border-hairline px-3 py-2 text-left text-sm text-muted-foreground transition-colors hover:bg-elevated/60 hover:text-foreground"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="space-y-5">
              {messages.map((m) => (
                <Message key={m.id} role={m.role} content={m.content} />
              ))}
              {pending && <Message role="user" content={pending} />}
              {sendMutation.isPending && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Loader2 className="size-4 animate-spin text-signal" />
                  Thinking…
                </div>
              )}
              <div ref={scrollRef} />
            </div>
          )}
        </div>

        {hasHistory && (
          <div className="mt-3 flex flex-wrap gap-2">
            {QUICK_PROMPTS.map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => submit(p)}
                disabled={sendMutation.isPending}
                className="rounded-full border border-hairline bg-card/40 px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:border-signal/40 hover:bg-signal/10 hover:text-foreground disabled:opacity-50"
              >
                {p}
              </button>
            ))}
          </div>
        )}

        <form
          onSubmit={(e) => {
            e.preventDefault();
            submit(input);
          }}
          className="mt-3 flex items-end gap-2"
        >
          <Textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKey}
            placeholder="Ask about your subscriptions…"
            disabled={sendMutation.isPending}
            rows={2}
            className="resize-none rounded-xl border-hairline bg-card/40"
          />
          <Button
            type="submit"
            disabled={sendMutation.isPending || !input.trim()}
            size="icon"
            className="size-11 shrink-0 bg-signal text-signal-foreground hover:opacity-90"
          >
            {sendMutation.isPending ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />}
          </Button>
        </form>
      </div>
    </AppShell>
  );
}

function Message({ role, content }: { role: string; content: string }) {
  if (role === "user") {
    return (
      <div className="flex justify-end">
        <div className="max-w-[85%] rounded-2xl rounded-br-sm bg-signal px-4 py-2.5 text-sm text-signal-foreground">
          {content}
        </div>
      </div>
    );
  }
  return (
    <div className="flex gap-3">
      <div className="grid size-7 shrink-0 place-items-center rounded-full bg-signal/15 text-signal">
        <Sparkles className="size-3.5" />
      </div>
      <div className="flex-1 whitespace-pre-wrap text-sm leading-relaxed text-foreground">{content}</div>
    </div>
  );
}
