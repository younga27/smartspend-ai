import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Upload, Sparkles, AlertTriangle, CheckCircle2, FileText, Loader2 } from "lucide-react";
import { parseImportText, bulkCreateSubscriptions } from "@/lib/import.functions";
import { generateRecommendations } from "@/lib/recommendations.functions";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/import")({
  component: ImportPage,
  head: () => ({ meta: [{ title: "Bulk import · Smart detection" }] }),
});

const SAMPLE = `2026-06-01,Netflix,15.49,USD,subscription
2026-06-03,AWS,243.12,USD,cloud
2026-06-04,Notion,16.00,USD,saas
2026-06-08,Figma Pro,15.00,USD,saas
2026-06-10,ChatGPT Plus,20.00,USD,ai
2026-06-12,Spotify Family,16.99,USD,music
2026-06-15,Zoom Standard,14.99,USD,saas
2026-06-15,Zoom Pro,19.99,USD,saas
2026-06-20,Adobe Creative Cloud,59.99,USD,saas`;

type ParsedItem = {
  name: string;
  amount: number;
  currency: string;
  billing_frequency: "daily" | "weekly" | "monthly" | "quarterly" | "yearly";
  category: string;
  next_billing_date: string;
  confidence: number;
  source_line?: string | null;
  is_duplicate?: boolean;
};

function ImportPage() {
  const [text, setText] = useState("");
  const [items, setItems] = useState<ParsedItem[]>([]);
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const navigate = useNavigate();
  const qc = useQueryClient();

  const parseFn = useServerFn(parseImportText);
  const bulkFn = useServerFn(bulkCreateSubscriptions);
  const generateRecsFn = useServerFn(generateRecommendations);

  const parseMut = useMutation({
    mutationFn: async (raw: string) => parseFn({ data: { text: raw } }),
    onSuccess: (res) => {
      const arr = (res.items ?? []) as ParsedItem[];
      setItems(arr);
      // pre-select non-duplicates with confidence > 0.5
      setSelected(
        new Set(
          arr
            .map((it, i) => (!it.is_duplicate && it.confidence > 0.5 ? i : -1))
            .filter((i) => i >= 0),
        ),
      );
      if (arr.length === 0) toast.error("No subscriptions detected. Try a different format.");
      else toast.success(`Detected ${arr.length} potential subscription${arr.length === 1 ? "" : "s"}`);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const importMut = useMutation({
    mutationFn: async () => {
      const picks = items
        .filter((_, i) => selected.has(i))
        .map(({ confidence: _c, source_line: _s, is_duplicate: _d, ...rest }) => rest);
      return bulkFn({ data: { items: picks } });
    },
    onSuccess: async (res) => {
      toast.success(`Imported ${res.inserted} subscription${res.inserted === 1 ? "" : "s"}`);
      // Refresh subscriptions (dashboard + analytics share this key)
      await qc.invalidateQueries({ queryKey: ["subscriptions"] });
      // Kick off a fresh AI savings pass in the background so the Savings page is ready
      toast.message("Refreshing AI savings recommendations…");
      generateRecsFn()
        .then(() => qc.invalidateQueries({ queryKey: ["recommendations"] }))
        .catch(() => qc.invalidateQueries({ queryKey: ["recommendations"] }));
      navigate({ to: "/dashboard" });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  async function handleFile(file: File) {
    const txt = await file.text();
    setText(txt.slice(0, 50_000));
  }

  function toggle(i: number) {
    const next = new Set(selected);
    if (next.has(i)) next.delete(i);
    else next.add(i);
    setSelected(next);
  }

  const dupCount = items.filter((i) => i.is_duplicate).length;
  const selectedCount = selected.size;
  const totalMonthly = items
    .filter((_, i) => selected.has(i))
    .reduce((sum, it) => {
      const mult =
        it.billing_frequency === "yearly"
          ? 1 / 12
          : it.billing_frequency === "quarterly"
            ? 1 / 3
            : it.billing_frequency === "weekly"
              ? 4.33
              : it.billing_frequency === "daily"
                ? 30
                : 1;
      return sum + it.amount * mult;
    }, 0);

  return (
    <AppShell>
      <div className="max-w-5xl">
        <div className="mb-6 flex items-center gap-3">
          <div className="grid size-10 place-items-center rounded-lg border border-hairline bg-elevated">
            <Upload className="size-5" />
          </div>
          <div>
            <h1 className="text-2xl font-semibold tracking-tight" style={{ fontFamily: "var(--font-display)" }}>
              Bulk import
            </h1>
            <p className="text-sm text-muted-foreground">
              Paste a CSV, bank statement, or invoice list. AI detects subscriptions, flags duplicates, and pre-fills the import.
            </p>
          </div>
        </div>

        {items.length === 0 ? (
          <Card className="p-6">
            <div className="flex items-center justify-between gap-3 mb-3">
              <label className="text-sm font-medium">Paste raw data</label>
              <div className="flex gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setText(SAMPLE)}
                  disabled={parseMut.isPending}
                >
                  <FileText className="size-4" /> Load sample
                </Button>
                <label className="inline-flex">
                  <input
                    type="file"
                    accept=".csv,.txt,.tsv"
                    className="hidden"
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) handleFile(f);
                    }}
                  />
                  <span className="inline-flex items-center gap-1.5 cursor-pointer rounded-md border border-hairline px-3 py-1.5 text-sm hover:bg-elevated">
                    <Upload className="size-4" /> Upload file
                  </span>
                </label>
              </div>
            </div>
            <Textarea
              value={text}
              onChange={(e) => setText(e.target.value.slice(0, 50_000))}
              placeholder="Paste CSV rows, bank statement lines, or any list of charges…"
              rows={12}
              className="font-mono text-xs"
            />
            <div className="mt-4 flex items-center justify-between">
              <p className="text-xs text-muted-foreground">{text.length.toLocaleString()} / 50,000 chars</p>
              <Button
                onClick={() => parseMut.mutate(text)}
                disabled={text.trim().length < 10 || parseMut.isPending}
              >
                {parseMut.isPending ? (
                  <>
                    <Loader2 className="size-4 animate-spin" /> Analyzing…
                  </>
                ) : (
                  <>
                    <Sparkles className="size-4" /> Detect subscriptions
                  </>
                )}
              </Button>
            </div>
          </Card>
        ) : (
          <>
            <div className="mb-4 grid grid-cols-3 gap-3">
              <Card className="p-3">
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Detected</div>
                <div className="text-2xl font-semibold">{items.length}</div>
              </Card>
              <Card className="p-3">
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Duplicates flagged</div>
                <div className="text-2xl font-semibold text-amber-500">{dupCount}</div>
              </Card>
              <Card className="p-3">
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Selected /mo</div>
                <div className="text-2xl font-semibold">${totalMonthly.toFixed(0)}</div>
              </Card>
            </div>

            <Card className="overflow-hidden">
              <div className="flex items-center justify-between gap-3 border-b border-hairline px-4 py-3">
                <div className="flex items-center gap-2">
                  <Checkbox
                    checked={selectedCount === items.length}
                    onCheckedChange={(v) => {
                      if (v) setSelected(new Set(items.map((_, i) => i)));
                      else setSelected(new Set());
                    }}
                  />
                  <span className="text-sm">
                    {selectedCount} of {items.length} selected
                  </span>
                </div>
                <div className="flex gap-2">
                  <Button variant="ghost" size="sm" onClick={() => { setItems([]); setText(""); }}>
                    Start over
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => importMut.mutate()}
                    disabled={selectedCount === 0 || importMut.isPending}
                  >
                    {importMut.isPending ? (
                      <><Loader2 className="size-4 animate-spin" /> Importing…</>
                    ) : (
                      <><CheckCircle2 className="size-4" /> Import {selectedCount}</>
                    )}
                  </Button>
                </div>
              </div>

              <ul className="divide-y divide-hairline">
                {items.map((it, i) => (
                  <li
                    key={i}
                    className={`flex items-center gap-3 px-4 py-3 text-sm ${
                      it.is_duplicate ? "bg-amber-500/5" : ""
                    }`}
                  >
                    <Checkbox checked={selected.has(i)} onCheckedChange={() => toggle(i)} />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-medium truncate">{it.name}</span>
                        <Badge variant="outline" className="text-[10px]">{it.category}</Badge>
                        <Badge variant="outline" className="text-[10px]">{it.billing_frequency}</Badge>
                        {it.is_duplicate && (
                          <span className="inline-flex items-center gap-1 text-[10px] text-amber-500">
                            <AlertTriangle className="size-3" /> Possible duplicate
                          </span>
                        )}
                        {it.confidence < 0.6 && (
                          <span className="text-[10px] text-muted-foreground">low confidence</span>
                        )}
                      </div>
                      {it.source_line && (
                        <p className="mt-0.5 truncate font-mono text-[10px] text-muted-foreground">
                          {it.source_line}
                        </p>
                      )}
                    </div>
                    <div className="text-right shrink-0">
                      <div className="font-semibold tabular-nums">
                        {it.currency} {it.amount.toFixed(2)}
                      </div>
                      <div className="text-[10px] text-muted-foreground">{it.next_billing_date}</div>
                    </div>
                  </li>
                ))}
              </ul>
            </Card>
          </>
        )}
      </div>
    </AppShell>
  );
}
