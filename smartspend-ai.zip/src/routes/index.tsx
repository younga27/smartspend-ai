import { createFileRoute, Link } from "@tanstack/react-router";
import {
  BarChart3,
  Bell,
  CheckCircle2,
  LineChart,
  type LucideIcon,
  Mail,
  MessageCircle,
  ShieldCheck,
  Sparkles,
  TrendingDown,
  ArrowUpRight,
} from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "SmartSpend AI — White-label subscription intelligence for fintech" },
      {
        name: "description",
        content:
          "Embed AI-powered subscription tracking, savings recommendations, and renewal alerts directly inside your fintech app. SOC 2 ready, three lines to integrate.",
      },
      { property: "og:title", content: "SmartSpend AI — Subscription intelligence, embedded" },
      {
        property: "og:description",
        content:
          "The white-label engine that powers subscription dashboards, AI savings advice, and proactive alerts inside modern fintech apps.",
      },
      { property: "og:type", content: "website" },
    ],
    links: [
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Inter+Tight:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap",
      },
    ],
  }),
  component: LandingPage,
});

type Feature = {
  icon: LucideIcon;
  kicker: string;
  title: string;
  body: string;
};

const features: Feature[] = [
  {
    icon: BarChart3,
    kicker: "01 / Dashboard",
    title: "Subscription dashboard",
    body: "A unified view of every recurring charge across your customers' linked accounts — costs, billing cycles, renewal dates, in one elegant surface.",
  },
  {
    icon: TrendingDown,
    kicker: "02 / Savings",
    title: "AI savings finder",
    body: "Our models read usage signals and surface concrete savings: downgrade paths, duplicate services, dormant trials, and cheaper equivalents.",
  },
  {
    icon: Bell,
    kicker: "03 / Alerts",
    title: "Smart alerts",
    body: "Renewals, free-trial expirations, price increases — proactive nudges delivered in-app, by email, or pushed through your existing messaging.",
  },
  {
    icon: MessageCircle,
    kicker: "04 / Assistant",
    title: "AI chat assistant",
    body: "Customers ask plain-language questions — 'where can I cut $50?' — and get personalized, account-aware financial guidance instantly.",
  },
  {
    icon: LineChart,
    kicker: "05 / Analytics",
    title: "Spending analytics",
    body: "Category trends, cohort benchmarks, and forecasted spend. Drop our charts into your app, or stream the raw aggregates over our API.",
  },
  {
    icon: Mail,
    kicker: "06 / Notifications",
    title: "Email notifications",
    body: "Branded, deliverable transactional email — sent from your domain, written by the assistant, never generic. Opt-out compliant by default.",
  },
];

const partners = [
  "MERIDIAN",
  "NORTHWIND",
  "PARALLEL",
  "OAK & RIVER",
  "FIGURE",
  "LEDGER CO.",
  "STILLWATER",
  "ATLAS BANK",
];

const tickerItems = [
  { label: "Avg. monthly savings surfaced / user", value: "$71.40" },
  { label: "Subscriptions detected / user", value: "14.2" },
  { label: "Trial expirations prevented", value: "98.6%" },
  { label: "API latency p95", value: "112ms" },
  { label: "Integration time", value: "< 1 day" },
  { label: "Embedded across", value: "37 fintechs" },
];

function LandingPage() {
  return (
    <div className="relative min-h-screen overflow-hidden bg-background text-foreground">
      <Nav />
      <Hero />
      <PartnerStrip />
      <Features />
      <EmbedSection />
      <Trust />
      <FinalCta />
      <Footer />
    </div>
  );
}

/* ---------- NAV ---------- */
function Nav() {
  return (
    <header className="sticky top-0 z-50 border-b border-hairline bg-background/70 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6">
        <a href="#" className="flex items-center gap-2.5">
          <LogoMark />
          <span className="text-[15px] font-medium tracking-tight">SmartSpend AI</span>
        </a>

        <nav className="hidden items-center gap-8 text-sm text-muted-foreground md:flex">
          <a href="#product" className="transition-colors hover:text-foreground">Product</a>
          <a href="#embed" className="transition-colors hover:text-foreground">Embed</a>
          <a href="#trust" className="transition-colors hover:text-foreground">Trust</a>
          <a href="#" className="transition-colors hover:text-foreground">Docs</a>
        </nav>

        <div className="flex items-center gap-2">
          <Link
            to="/auth"
            className="hidden rounded-md px-3 py-2 text-sm text-muted-foreground transition-colors hover:text-foreground sm:inline-block"
          >
            Sign in
          </Link>
          <Link
            to="/auth"
            className="inline-flex items-center gap-1.5 rounded-md bg-signal px-3.5 py-2 text-sm font-medium text-signal-foreground transition-opacity hover:opacity-90"
          >
            Open app
            <ArrowUpRight className="size-3.5" />
          </Link>
        </div>
      </div>
    </header>
  );
}

function LogoMark() {
  return (
    <div className="relative grid size-7 place-items-center rounded-md bg-signal text-signal-foreground">
      <svg viewBox="0 0 24 24" className="size-4" fill="none" aria-hidden>
        <path d="M5 14L10 9L14 13L19 6" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M14 6H19V11" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    </div>
  );
}

/* ---------- HERO ---------- */
function Hero() {
  return (
    <section className="relative isolate overflow-hidden">
      <div className="absolute inset-0 grid-bg opacity-60 [mask-image:radial-gradient(ellipse_at_top,black_30%,transparent_70%)]" aria-hidden />
      <div className="absolute left-1/2 top-[-10%] -z-10 h-[480px] w-[900px] -translate-x-1/2 rounded-full bg-signal/20 blur-[140px]" aria-hidden />

      <div className="mx-auto max-w-7xl px-6 pb-24 pt-20 md:pt-28">
        <div className="grid items-start gap-16 lg:grid-cols-12">
          <div className="lg:col-span-7">
            <div className="inline-flex items-center gap-2 rounded-full border border-hairline bg-card/60 px-3 py-1 text-xs text-muted-foreground rise-in">
              <span className="relative inline-flex">
                <span className="absolute inset-0 rounded-full bg-signal/70 pulse-dot" />
                <span className="relative size-1.5 rounded-full bg-signal" />
              </span>
              White-label · v2.4 shipped this week
            </div>

            <h1 className="mt-6 font-display text-[clamp(2.8rem,6vw,5.25rem)] leading-[1.02] tracking-[-0.02em] text-balance rise-in">
              Subscription intelligence,{" "}
              <span className="italic text-muted-foreground">embedded</span> inside your fintech.
            </h1>

            <p className="mt-6 max-w-xl text-[17px] leading-relaxed text-muted-foreground text-pretty rise-in">
              SmartSpend AI is the engine behind subscription dashboards, savings recommendations,
              and renewal alerts for the world&apos;s most considered fintech apps. Three lines to
              integrate. Your brand. Your customers&apos; data.
            </p>

            <div className="mt-9 flex flex-wrap items-center gap-3 rise-in">
              <a
                href="#cta"
                className="inline-flex items-center gap-2 rounded-md bg-signal px-5 py-3 text-sm font-medium text-signal-foreground transition-opacity hover:opacity-90"
              >
                Request a demo <ArrowUpRight className="size-4" />
              </a>
              <a
                href="#embed"
                className="inline-flex items-center gap-2 rounded-md border border-border bg-card/40 px-5 py-3 text-sm font-medium text-foreground transition-colors hover:bg-card"
              >
                See it embedded
              </a>
            </div>

            <div className="mt-8 flex items-center gap-6 text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-1.5"><CheckCircle2 className="size-3.5 text-signal" /> SOC 2 Type II</span>
              <span className="inline-flex items-center gap-1.5"><CheckCircle2 className="size-3.5 text-signal" /> GDPR &amp; CCPA</span>
              <span className="inline-flex items-center gap-1.5"><CheckCircle2 className="size-3.5 text-signal" /> No PCI scope</span>
            </div>
          </div>

          <div className="lg:col-span-5">
            <PhoneMock />
          </div>
        </div>
      </div>
    </section>
  );
}

/* Embedded-app frame, designed to feel like SmartSpend running inside a partner fintech */
function PhoneMock() {
  return (
    <div className="relative mx-auto w-full max-w-[420px] rise-in">
      <div className="pointer-events-none absolute -inset-10 -z-10 rounded-[3rem] bg-signal/10 blur-3xl" aria-hidden />
      <div className="rounded-[2.25rem] border border-hairline bg-card/70 p-3 shadow-2xl backdrop-blur-xl">
        <div className="overflow-hidden rounded-[1.75rem] bg-background">
          {/* Partner app header */}
          <div className="flex items-center justify-between border-b border-hairline px-5 py-3.5">
            <div className="flex items-center gap-2">
              <div className="size-5 rounded-md bg-foreground/90" />
              <span className="text-xs font-medium tracking-wider">MERIDIAN BANK</span>
            </div>
            <span className="font-mono text-[10px] text-muted-foreground">powered by SmartSpend</span>
          </div>

          <div className="space-y-5 p-5">
            <div>
              <p className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">Monthly subscriptions</p>
              <div className="mt-1 flex items-baseline gap-2">
                <span className="font-display text-5xl tracking-tight">$248</span>
                <span className="font-mono text-xs text-signal">−$71 vs last mo</span>
              </div>
            </div>

            {/* Sparkline */}
            <div className="relative h-24 w-full">
              <svg viewBox="0 0 320 96" className="absolute inset-0 size-full" preserveAspectRatio="none" aria-hidden>
                <defs>
                  <linearGradient id="spark" x1="0" x2="0" y1="0" y2="1">
                    <stop offset="0%" stopColor="oklch(0.82 0.17 142)" stopOpacity="0.5" />
                    <stop offset="100%" stopColor="oklch(0.82 0.17 142)" stopOpacity="0" />
                  </linearGradient>
                </defs>
                <path
                  d="M0 70 L40 60 L70 65 L110 45 L150 52 L190 30 L230 38 L270 22 L320 28 L320 96 L0 96 Z"
                  fill="url(#spark)"
                />
                <path
                  d="M0 70 L40 60 L70 65 L110 45 L150 52 L190 30 L230 38 L270 22 L320 28"
                  stroke="oklch(0.82 0.17 142)"
                  strokeWidth="1.6"
                  fill="none"
                  strokeLinecap="round"
                />
              </svg>
            </div>

            {/* Sub items */}
            <div className="space-y-2.5">
              {[
                { name: "Notion Family", price: "$19.99", note: "Renews in 4d", flag: "renewal" },
                { name: "ChatGPT Plus", price: "$20.00", note: "Duplicate of Claude Pro", flag: "save" },
                { name: "FitnessClub+", price: "$48.00", note: "Trial ends in 2d", flag: "trial" },
              ].map((s) => (
                <div key={s.name} className="flex items-center justify-between rounded-lg border border-hairline bg-elevated/60 px-3 py-2.5">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">{s.name}</p>
                    <p className="truncate font-mono text-[11px] text-muted-foreground">{s.note}</p>
                  </div>
                  <div className="ml-3 flex items-center gap-2">
                    <span className="font-mono text-sm">{s.price}</span>
                    <span
                      className={
                        "rounded-full px-2 py-0.5 text-[10px] " +
                        (s.flag === "save"
                          ? "bg-signal/15 text-signal"
                          : s.flag === "trial"
                            ? "border border-hairline text-muted-foreground"
                            : "border border-hairline text-muted-foreground")
                      }
                    >
                      {s.flag === "save" ? "Save $20" : s.flag === "trial" ? "Trial" : "Soon"}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Assistant bubble */}
            <div className="rounded-lg border border-hairline bg-card/80 p-3">
              <div className="flex items-center gap-2 text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                <Sparkles className="size-3 text-signal" /> Assistant
              </div>
              <p className="mt-1.5 text-[13px] leading-relaxed text-foreground/90">
                You&apos;re paying for both ChatGPT Plus and Claude Pro. Cancelling one saves
                <span className="text-signal"> $240/yr</span> with no overlap.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------- PARTNER STRIP (ticker) ---------- */
function PartnerStrip() {
  return (
    <section className="relative border-y border-hairline bg-elevated/40">
      <div className="mx-auto max-w-7xl px-6 py-6">
        <p className="mb-4 text-center font-mono text-[11px] uppercase tracking-[0.22em] text-muted-foreground">
          Embedded inside finance teams at
        </p>
        <div className="relative overflow-hidden">
          <div className="ticker flex w-max gap-12 whitespace-nowrap font-mono text-sm tracking-[0.18em] text-muted-foreground">
            {[...partners, ...partners].map((p, i) => (
              <span key={i} className="inline-flex items-center gap-3">
                <span className="size-1 rounded-full bg-signal/70" /> {p}
              </span>
            ))}
          </div>
          <div className="pointer-events-none absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-background to-transparent" />
          <div className="pointer-events-none absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-background to-transparent" />
        </div>
      </div>
    </section>
  );
}

/* ---------- FEATURES ---------- */
function Features() {
  return (
    <section id="product" className="relative mx-auto max-w-7xl px-6 py-28">
      <div className="grid gap-10 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-signal">— Capabilities</p>
          <h2 className="mt-4 font-display text-[clamp(2rem,4.4vw,3.6rem)] leading-[1.05] tracking-[-0.015em] text-balance">
            Six pillars. <span className="italic text-muted-foreground">One quiet engine.</span>
          </h2>
          <p className="mt-5 max-w-md text-muted-foreground">
            Use the full suite, or pluck the modules you need. Every surface ships as React
            components, headless hooks, and a typed REST API.
          </p>
        </div>
        <div className="lg:col-span-7">
          <div className="grid grid-cols-1 gap-px overflow-hidden rounded-xl border border-hairline bg-hairline sm:grid-cols-2">
            {features.map((f) => (
              <FeatureCard key={f.title} {...f} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function FeatureCard({ icon: Icon, kicker, title, body }: Feature) {
  return (
    <article className="group relative flex flex-col gap-3 bg-card p-7 transition-colors hover:bg-elevated">
      <div className="flex items-center justify-between">
        <span className="grid size-9 place-items-center rounded-md bg-signal/10 text-signal">
          <Icon className="size-4" />
        </span>
        <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">{kicker}</span>
      </div>
      <h3 className="mt-3 text-lg font-medium tracking-tight" style={{ fontFamily: "var(--font-sans)" }}>
        {title}
      </h3>
      <p className="text-sm leading-relaxed text-muted-foreground">{body}</p>
    </article>
  );
}

/* ---------- EMBED SECTION ---------- */
function EmbedSection() {
  return (
    <section id="embed" className="relative bg-cream py-28 text-surface-foreground">
      <div className="mx-auto grid max-w-7xl items-center gap-14 px-6 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-surface-foreground/60">— Integration</p>
          <h2 className="mt-4 font-display text-[clamp(2rem,4.4vw,3.4rem)] leading-[1.05] tracking-[-0.015em] text-balance">
            Embed in <span className="italic">three lines.</span>
          </h2>
          <p className="mt-5 max-w-md text-surface-foreground/70">
            Drop the component, pass a session token, ship to production. No data leaves your
            customer&apos;s tenant — we operate as a stateless processor.
          </p>
          <ul className="mt-7 space-y-3 text-sm text-surface-foreground/80">
            {[
              "React, React Native, and headless web components",
              "Themeable to your design tokens out of the box",
              "Hosted aggregates API for native dashboards",
              "Webhooks for renewals, alerts, and savings events",
            ].map((t) => (
              <li key={t} className="flex items-start gap-2.5">
                <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-surface-foreground" />
                {t}
              </li>
            ))}
          </ul>
        </div>

        <div className="lg:col-span-7">
          <div className="overflow-hidden rounded-xl border border-surface-foreground/15 bg-background text-foreground shadow-[0_30px_80px_-30px_rgba(0,0,0,0.35)]">
            <div className="flex items-center justify-between border-b border-hairline px-4 py-2.5">
              <div className="flex items-center gap-1.5">
                <span className="size-2.5 rounded-full bg-foreground/20" />
                <span className="size-2.5 rounded-full bg-foreground/20" />
                <span className="size-2.5 rounded-full bg-foreground/20" />
              </div>
              <span className="font-mono text-[11px] text-muted-foreground">app/subscriptions.tsx</span>
              <span className="font-mono text-[11px] text-signal">● live</span>
            </div>
            <pre className="overflow-x-auto px-6 py-7 font-mono text-[13px] leading-[1.85]">
              <code>
                <span className="text-muted-foreground">{`// 1. Install`}</span>
                {`\n`}
                <span className="text-signal">npm</span>
                <span className="text-foreground/80">{` install `}</span>
                <span className="text-foreground">@smartspend/react</span>
                {`\n\n`}
                <span className="text-muted-foreground">{`// 2. Mount inside your app`}</span>
                {`\n`}
                <span className="text-signal">{`import`}</span>
                <span className="text-foreground/80">{` { SubscriptionHub } `}</span>
                <span className="text-signal">{`from`}</span>
                <span className="text-foreground/80">{` `}</span>
                <span className="text-foreground">{`"@smartspend/react"`}</span>
                {`\n\n`}
                <span className="text-signal">{`export default function`}</span>
                <span className="text-foreground/80">{` `}</span>
                <span className="text-foreground">{`Subscriptions`}</span>
                <span className="text-foreground/80">{`() {`}</span>
                {`\n  `}
                <span className="text-signal">{`return`}</span>
                <span className="text-foreground/80">{` <`}</span>
                <span className="text-foreground">{`SubscriptionHub`}</span>
                <span className="text-foreground/80">{` token={session.smartspend} />`}</span>
                {`\n`}
                <span className="text-foreground/80">{`}`}</span>
              </code>
            </pre>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------- TRUST ---------- */
function Trust() {
  return (
    <section id="trust" className="relative overflow-hidden border-y border-hairline">
      <div className="mx-auto grid max-w-7xl gap-px bg-hairline md:grid-cols-3">
        {tickerItems.slice(0, 3).map((m) => (
          <div key={m.label} className="bg-background p-10">
            <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground">{m.label}</p>
            <p className="mt-3 font-display text-5xl tracking-tight">{m.value}</p>
          </div>
        ))}
      </div>
      <div className="mx-auto max-w-7xl px-6 py-16">
        <div className="grid items-start gap-10 md:grid-cols-2">
          <div>
            <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-signal">— Trust</p>
            <h2 className="mt-4 font-display text-[clamp(1.8rem,3.6vw,2.8rem)] leading-[1.05] tracking-[-0.015em] text-balance">
              Built for the compliance team, <span className="italic text-muted-foreground">not just the product team.</span>
            </h2>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            {[
              { icon: ShieldCheck, title: "SOC 2 Type II", body: "Audited annually. Reports under NDA on request." },
              { icon: ShieldCheck, title: "GDPR / CCPA", body: "EU and US data residency. DPA signed at contract." },
              { icon: ShieldCheck, title: "No PCI scope", body: "We never touch card numbers — only aggregates." },
              { icon: ShieldCheck, title: "Stateless processor", body: "Customer data stays inside your tenant." },
            ].map((b) => (
              <div key={b.title} className="rounded-lg border border-hairline bg-card/50 p-5">
                <b.icon className="size-4 text-signal" />
                <p className="mt-3 text-sm font-medium">{b.title}</p>
                <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{b.body}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------- FINAL CTA ---------- */
function FinalCta() {
  return (
    <section id="cta" className="relative isolate overflow-hidden">
      <div className="absolute inset-0 grid-bg opacity-50 [mask-image:radial-gradient(ellipse_at_center,black_30%,transparent_75%)]" aria-hidden />
      <div className="absolute left-1/2 top-1/2 -z-10 size-[600px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-signal/15 blur-[160px]" aria-hidden />

      <div className="mx-auto max-w-4xl px-6 py-32 text-center">
        <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-signal">— Get started</p>
        <h2 className="mt-5 font-display text-[clamp(2.4rem,6vw,4.6rem)] leading-[1.02] tracking-[-0.02em] text-balance">
          Ship subscription intelligence <span className="italic text-muted-foreground">this quarter.</span>
        </h2>
        <p className="mx-auto mt-6 max-w-xl text-muted-foreground text-pretty">
          A 30-minute demo with our integrations team. We&apos;ll mock up SmartSpend in your
          brand and walk through go-live.
        </p>

        <form className="mx-auto mt-10 flex max-w-md flex-col gap-3 sm:flex-row" onSubmit={(e) => e.preventDefault()}>
          <input
            type="email"
            required
            placeholder="you@fintech.com"
            className="h-12 flex-1 rounded-md border border-border bg-card/60 px-4 text-sm outline-none ring-signal/40 transition placeholder:text-muted-foreground/70 focus:ring-2"
          />
          <button
            type="submit"
            className="inline-flex h-12 items-center justify-center gap-2 rounded-md bg-signal px-5 text-sm font-medium text-signal-foreground transition-opacity hover:opacity-90"
          >
            Request demo <ArrowUpRight className="size-4" />
          </button>
        </form>
        <p className="mt-3 text-xs text-muted-foreground">Average response time: 4 business hours.</p>
      </div>
    </section>
  );
}

/* ---------- FOOTER ---------- */
function Footer() {
  return (
    <footer className="border-t border-hairline">
      <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-8 px-6 py-12 md:flex-row md:items-center">
        <div className="flex items-center gap-2.5">
          <LogoMark />
          <span className="text-sm font-medium tracking-tight">SmartSpend AI</span>
          <span className="ml-3 font-mono text-[11px] text-muted-foreground">v2.4 · {new Date().getFullYear()}</span>
        </div>
        <nav className="flex flex-wrap gap-6 text-sm text-muted-foreground">
          <a href="#" className="hover:text-foreground">Product</a>
          <a href="#" className="hover:text-foreground">Docs</a>
          <a href="#" className="hover:text-foreground">Security</a>
          <a href="#" className="hover:text-foreground">Privacy</a>
          <a href="#" className="hover:text-foreground">Contact</a>
        </nav>
      </div>
    </footer>
  );
}
