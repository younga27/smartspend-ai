import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const listRecommendations = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("savings_recommendations")
      .select("*")
      .eq("archived", false)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const generateRecommendations = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { callLovableAi } = await import("./ai-gateway.server");

    const { data: subs, error: subErr } = await context.supabase
      .from("subscriptions")
      .select("name, amount, currency, billing_frequency, category, is_active");
    if (subErr) throw new Error(subErr.message);

    const active = (subs ?? []).filter((s) => s.is_active);
    if (active.length === 0) {
      return { recommendations: [], message: "Add at least one subscription to generate recommendations." };
    }

    const list = active
      .map((s) => `- ${s.name}: ${s.currency} ${s.amount}/${s.billing_frequency} (${s.category})`)
      .join("\n");

    const raw = await callLovableAi({
      messages: [
        {
          role: "system",
          content:
            "You are a financial advisor. Return ONLY valid JSON, no prose. Schema: { \"recommendations\": [{ \"title\": string, \"description\": string, \"potential_savings\": number }] }. Provide 3-5 concrete, actionable monthly savings ideas based on the user's subscriptions. `potential_savings` is the estimated USD saved per month.",
        },
        { role: "user", content: `My active subscriptions:\n${list}\n\nReturn the JSON now.` },
      ],
      response_format: { type: "json_object" },
    });

    let parsed: { recommendations?: Array<{ title?: string; description?: string; potential_savings?: number }> } = {};
    try {
      const jsonStart = raw.indexOf("{");
      const jsonEnd = raw.lastIndexOf("}");
      parsed = JSON.parse(raw.slice(jsonStart, jsonEnd + 1));
    } catch {
      throw new Error("AI returned malformed JSON. Please try again.");
    }

    const recs = (parsed.recommendations ?? [])
      .filter((r) => r && r.title && r.description)
      .slice(0, 6)
      .map((r) => ({
        user_id: context.userId,
        title: String(r.title),
        description: String(r.description),
        potential_savings: Number(r.potential_savings ?? 0) || 0,
      }));

    if (recs.length === 0) return { recommendations: [], message: "No recommendations generated." };

    const { data: inserted, error } = await context.supabase
      .from("savings_recommendations")
      .insert(recs)
      .select("*");
    if (error) throw new Error(error.message);

    return { recommendations: inserted ?? [], message: null };
  });

export const archiveRecommendation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("savings_recommendations")
      .update({ archived: true })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
