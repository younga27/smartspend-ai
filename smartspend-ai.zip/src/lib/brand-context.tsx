import { createContext, useContext, useState, useEffect, type ReactNode } from "react";

export type BrandPreset = {
  id: string;
  name: string;
  tagline: string;
  // CSS variable overrides
  signal: string; // oklch
  signalFg: string;
  fontDisplay: string;
  logoMark: string; // single character / emoji-ish glyph
};

export const BRANDS: BrandPreset[] = [
  {
    id: "smartspend",
    name: "SmartSpend AI",
    tagline: "Default white-label",
    signal: "oklch(0.82 0.17 142)",
    signalFg: "oklch(0.18 0.012 75)",
    fontDisplay: '"Instrument Serif", ui-serif, Georgia, serif',
    logoMark: "S",
  },
  {
    id: "apex",
    name: "Apex Bank",
    tagline: "Retail banking partner",
    signal: "oklch(0.68 0.18 245)",
    signalFg: "oklch(0.98 0.005 0)",
    fontDisplay: '"Inter Tight", ui-sans-serif, system-ui, sans-serif',
    logoMark: "A",
  },
  {
    id: "coral",
    name: "Coral Wealth",
    tagline: "Advisor white-label",
    signal: "oklch(0.72 0.18 35)",
    signalFg: "oklch(0.16 0.01 60)",
    fontDisplay: '"Playfair Display", ui-serif, Georgia, serif',
    logoMark: "C",
  },
  {
    id: "verde",
    name: "Verde Capital",
    tagline: "Fintech neobank",
    signal: "oklch(0.74 0.19 160)",
    signalFg: "oklch(0.16 0.01 160)",
    fontDisplay: '"DM Serif Display", ui-serif, Georgia, serif',
    logoMark: "V",
  },
];

type BrandCtx = {
  brand: BrandPreset;
  setBrandId: (id: string) => void;
};

const Ctx = createContext<BrandCtx | null>(null);

export function BrandProvider({ children }: { children: ReactNode }) {
  const [brandId, setBrandId] = useState<string>("smartspend");

  useEffect(() => {
    try {
      const saved = localStorage.getItem("ss-brand");
      if (saved) setBrandId(saved);
    } catch {}
  }, []);

  useEffect(() => {
    const b = BRANDS.find((x) => x.id === brandId) ?? BRANDS[0];
    const root = document.documentElement;
    root.style.setProperty("--signal", b.signal);
    root.style.setProperty("--signal-foreground", b.signalFg);
    root.style.setProperty("--font-display", b.fontDisplay);
    try {
      localStorage.setItem("ss-brand", brandId);
    } catch {}
  }, [brandId]);

  const brand = BRANDS.find((x) => x.id === brandId) ?? BRANDS[0];
  return <Ctx.Provider value={{ brand, setBrandId }}>{children}</Ctx.Provider>;
}

export function useBrand() {
  const v = useContext(Ctx);
  if (!v) throw new Error("useBrand must be used inside BrandProvider");
  return v;
}
