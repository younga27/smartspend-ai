import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const billingFrequencyEnum = z.enum(["daily", "weekly", "monthly", "quarterly", "yearly"]);

const parsedItemSchema = z.object({
  name: z.string().min(1).max(255),
  amount: z.number().positive().max(1_000_000),
  currency: z.string().length(3).default("USD"),
  billing_frequency: billingFrequencyEnum,
  category: z.string().min(1).max(64),
  next_billing_date: z.string(),
  confidence: z.number().min(0).max(1).default(0.8),
  source_line: z.string().max(500).optional().nullable(),
});

const bulkInsertSchema = z.object({
  items: z.array(parsedItemSchema.omit({ confidence: true, source_line: true })).min(1).max(100),
});

/**
 * Smart-detect subscriptions from arbitrary text (CSV, bank statement paste, email export).
 * Uses Lovable AI to extract structured rows.
 */
export const parseImportText = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ text: z.string().min(10).max(50_000) }).parse(d))
  .handler(async ({ data, context }) => {
    const { callLovableAi } = await import("@/lib/ai-gateway.server");

    // Get existing subs for duplicate detection
    const { data: existing } = await context.supabase
      .from("subscriptions")
      .select("name, amount, billing_frequency");

    const today = new Date().toISOString().slice(0, 10);

    const system = `You extract recurring subscriptions from raw text (CSV rows, bank statements, invoice lists, emails).
Return STRICT JSON: { "items": [{ "name", "amount", "currency", "billing_frequency", "category", "next_billing_date", "confidence", "source_line" }] }.
Rules:
- billing_frequency must be one of: daily, weekly, monthly, quarterly, yearly. Infer from cadence; default "monthly".
- next_billing_date: ISO date YYYY-MM-DD. If unknown, estimate 30 days from today (${today}).
- amount: positive number, no currency symbols.
- currency: 3-letter ISO (USD if unclear).
- category: short label (Software, Streaming, Cloud, Productivity, Marketing, Finance, AI, Other).
- confidence: 0-1, how sure this is actually a recurring subscription (vs one-time purchase).
- source_line: the original raw line (truncated to 200 chars) so the user can verify.
- SKIP one-off purchases, refunds, transfers, salary, ATM.
- Only output JSON. No prose.`;

    const userMsg = `Today: ${today}\n\nRaw input:\n${data.text}`;

    const raw = await callLovableAi({
      messages: [
        { role: "system", content: system },
        { role: "user", content: userMsg },
      ],
      response_format: { type: "json_object" },
      temperature: 0.1,
    });

    let parsed: unknown;
    try {
      parsed = JSON.parse(raw);
    } catch {
      // try to extract JSON block
      const match = raw.match(/\{[\s\S]*\}/);
      parsed = match ? JSON.parse(match[0]) : { items: [] };
    }

    const result = z.object({ items: z.array(parsedItemSchema) }).safeParse(parsed);
    if (!result.success) return { items: [], duplicates: [] as string[] };

    // Duplicate detection: name match (case-insensitive) OR same amount+frequency
    const existingList = existing ?? [];
    const items = result.data.items.map((it) => {
      const nameKey = it.name.toLowerCase().trim();
      const isDuplicate = existingList.some(
        (e) =>
          e.name.toLowerCase().trim() === nameKey ||
          (Math.abs(Number(e.amount) - it.amount) < 0.01 &&
            e.billing_frequency === it.billing_frequency),
      );
      return { ...it, is_duplicate: isDuplicate };
    });

    return { items, count: items.length };
  });

/**
 * Bulk insert verified subscriptions.
 */
export const bulkCreateSubscriptions = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => bulkInsertSchema.parse(d))
  .handler(async ({ data, context }) => {
    const rows = data.items.map((it) => ({ ...it, user_id: context.userId }));
    const { data: inserted, error } = await context.supabase
      .from("subscriptions")
      .insert(rows)
      .select();
    if (error) throw new Error(error.message);
    return { inserted: inserted?.length ?? 0 };
  });
