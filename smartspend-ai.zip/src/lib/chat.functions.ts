import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const listChatMessages = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("chat_messages")
      .select("id, role, content, created_at")
      .order("created_at", { ascending: true });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const sendChatMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({ message: z.string().min(1).max(4000) }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { callLovableAi } = await import("./ai-gateway.server");

    // Persist user message
    const { error: insertUserErr } = await context.supabase
      .from("chat_messages")
      .insert({ user_id: context.userId, role: "user", content: data.message });
    if (insertUserErr) throw new Error(insertUserErr.message);

    // Pull subscription context and history (last 20)
    const [{ data: subs }, { data: history }] = await Promise.all([
      context.supabase.from("subscriptions").select("name, amount, currency, billing_frequency, category, next_billing_date, is_active"),
      context.supabase
        .from("chat_messages")
        .select("role, content")
        .order("created_at", { ascending: false })
        .limit(20),
    ]);

    const subSummary = (subs ?? [])
      .filter((s) => s.is_active)
      .map((s) => `- ${s.name}: ${s.currency} ${s.amount}/${s.billing_frequency} (${s.category}, renews ${s.next_billing_date})`)
      .join("\n") || "No active subscriptions on file.";

    const system = `You are SmartSpend AI, a concise, friendly financial advisor focused on subscription spending.
You can see the user's active subscriptions. Be specific, reference real entries when relevant, and surface concrete savings ideas.
Keep responses short and skimmable. Use markdown lists when helpful.

User's active subscriptions:
${subSummary}`;

    const historyOrdered = (history ?? []).reverse();
    const assistant = await callLovableAi({
      messages: [
        { role: "system", content: system },
        ...historyOrdered.map((m) => ({
          role: m.role as "user" | "assistant",
          content: m.content,
        })),
      ],
    });

    const finalContent = assistant.trim() || "Sorry, I couldn't generate a response. Please try again.";

    const { data: row, error: insertAsstErr } = await context.supabase
      .from("chat_messages")
      .insert({ user_id: context.userId, role: "assistant", content: finalContent })
      .select("id, role, content, created_at")
      .single();
    if (insertAsstErr) throw new Error(insertAsstErr.message);

    return row;
  });

export const clearChatHistory = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { error } = await context.supabase
      .from("chat_messages")
      .delete()
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
